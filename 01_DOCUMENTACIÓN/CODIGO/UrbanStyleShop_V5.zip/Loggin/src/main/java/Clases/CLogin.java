package Clases;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class CLogin {

    private static int intentosFallidos = 0;

    public static class ResultadoLogin {
        public boolean exitoso;
        public boolean bloqueado;
        public String mensaje;

        public ResultadoLogin(boolean exitoso, boolean bloqueado, String mensaje) {
            this.exitoso = exitoso;
            this.bloqueado = bloqueado;
            this.mensaje = mensaje;
        }
    }

    public ResultadoLogin validaUsuario(JTextField usuario, JPasswordField contrasenia) {
        try {
            if (intentosFallidos >= 3) {
                return new ResultadoLogin(false, true, "Bloqueado. Espere 30 segundos.");
            }

            PreparedStatement ps;
            ResultSet rs;

            CConexion conexion = new CConexion();
            String consulta = "SELECT * FROM usuarios WHERE BINARY ingresoUsuario = ? AND BINARY ingresoContrasena = ?";
            ps = conexion.estableceConexion().prepareStatement(consulta);

            String contra = String.valueOf(contrasenia.getPassword());

            ps.setString(1, usuario.getText().trim());
            ps.setString(2, contra);

            rs = ps.executeQuery();

            if (rs.next()) {
                intentosFallidos = 0;
                return new ResultadoLogin(true, false, "Usuario correcto.");
            } else {
                intentosFallidos++;
                if (intentosFallidos >= 3) {
                    return new ResultadoLogin(false, true, "Demasiados intentos. Bloqueado 30 segundos.");
                } else {
                    return new ResultadoLogin(false, false, "Usuario o contraseña incorrectos. Intento " + intentosFallidos + " de 3.");
                }
            }

        } catch (Exception e) {
            return new ResultadoLogin(false, false, "ERROR: " + e.toString());
        }
    }

    public void resetearIntentos() {
        intentosFallidos = 0;
    }
}