/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.login;
import com.formdev.flatlaf.FlatLightLaf;  // Importación necesaria para FlatLaf
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
/**
 *
 * @author Usuario
 */
public class Login {

    public static void main(String[] args) {
           try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            System.err.println("No se pudo aplicar FlatLaf");
        }

        SwingUtilities.invokeLater(() -> {
            new FormLogin().setVisible(true);
        });
    }
}

